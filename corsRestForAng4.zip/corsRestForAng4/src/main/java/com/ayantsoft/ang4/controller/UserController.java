package com.ayantsoft.ang4.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.ang4.model.LoginClass;
import com.ayantsoft.ang4.model.LoginMst;


//as the class is annotated using @RestController now all the controller methods can be accessd by ip address
@RestController
public class UserController{

	

@RequestMapping(value="/",method=RequestMethod.GET)
public ModelAndView index(){
	ModelAndView mv = new ModelAndView("index");
	return mv;
}

@RequestMapping(value="/test",method=RequestMethod.GET)
public Integer test(){
	
	return 10;
}

@RequestMapping(value="/hello",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/angLoging
public void getLogin(){//here data received using @requestBody
	System.out.println("===========");//here after receiving the model you can do whatever you would like
	
}


@RequestMapping(value="/angLoging",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/angLoging
public ResponseEntity<?> getLogin(@RequestBody LoginMst login){//here data received using @requestBody
	System.out.println(login.getFirstname());//here after receiving the model you can do whatever you would like
	HttpStatus httpStatus = null;
	List<LoginMst>l=new ArrayList<LoginMst>();
	LoginMst login1=new LoginMst();
	login1.setFirstname("Fenil Patel");
	login1.setUserId("Somnath 001");
	login1.setMiddleName("kumar");
	login1.setLastname("Biswas");
	login1.setDescription("A User");
	login1.setPassword("somnathPassword");
		httpStatus=HttpStatus.OK;
	return new ResponseEntity<List<LoginMst>>(l,httpStatus);
}

//This two controller methods are designed for interacting with angular 4 and angular js
//if you use same property named object from client side it will be catched here in the server side 

/*@RequestMapping(value="/angularJs",method=RequestMethod.GET)
public ModelAndView getLoginFromAngularJs(){
	ModelAndView mv=new ModelAndView();
	mv.setViewName("ang1");
	return mv;
}*/
@RequestMapping(value="/getAngularJs",method=RequestMethod.POST)
public void getData(@RequestBody User user){
	System.out.println(user.getUsername());
}


}
