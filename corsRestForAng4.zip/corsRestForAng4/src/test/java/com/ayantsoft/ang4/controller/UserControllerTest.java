package com.ayantsoft.ang4.controller;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import test.config.TestBeanConfig;

@WebAppConfiguration 
@RunWith(SpringJUnit4ClassRunner.class) 
@ContextConfiguration(classes = {TestBeanConfig.class}) 

public class UserControllerTest {

	@Autowired
	private UserController ua;
	
	
	 @Test public void emp_Controller_Test1() { 
		 Integer i=ua.test();
		assertTrue( i== 0);
	}
	
	 @Test public void emp_Controller_Test2() { 
		 Integer i=ua.test();
		assertTrue( i> 0);
	}
}
